Person Site Project
==================

Use this as a starting point for your Personal site.

Use the site-plan.html to complete the planning for the site.

When you are ready to start building your site start with index.html.  Feel free to replace or change anything in that file.  It will become the homepage for your site.


